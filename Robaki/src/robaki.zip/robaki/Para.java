/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package robaki;

/**
 *
 * @author kayne
 */
public class Para {
    
    private int x;
    private int y;
    
    public Para(int kolumna, int wiersz) {
        x = kolumna;
        y = wiersz;
    }
    
    public int getX() {
        return x;
    }
    
    public int getY() {
        return y;
    }
    
}
