/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package robaki;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author kayne
 */
public class Robaki {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        final Logika logika = new Logika(10, 10);
        final List<Thread> lista = new ArrayList<>();

        /*for (int i = 0; i < 20; i++) {
         * lista.add(new Thread(new Robak(logika, i + 1)));
         * }*/

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Program(10, 10, logika, lista).setVisible(true);
            }
        });

        /*for (int i = 0; i < 20; i++) {
         * lista.get(i).start();
         * }*/

    }
}
