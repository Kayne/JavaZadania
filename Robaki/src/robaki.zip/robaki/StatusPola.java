/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package robaki;

/**
 *
 * @author kayne
 */
public enum StatusPola {
    
}
