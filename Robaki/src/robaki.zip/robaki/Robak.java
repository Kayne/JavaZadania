/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package robaki;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Klasa reprezentująca jednego robaka.
 *
 * @author kayne
 */
public class Robak implements Runnable {
    
    private boolean koniec = false;
    private int głowa_kolumna = 0;
    private int głowa_wiersz = 0;
    private int numer = 1;
    private int[][] ogon;
    /**
     * 1 - góra, 2 - w lewo, 3 - w prawo, 4 - w dół.
     */
    private int obecny_kierunek = 1;
    private Logika logika;
    Random randomGenerator = new Random();
    List<Para> lista = new ArrayList<>();

    /*public Robak(Logika log) {
     * logika = log;
     * ogon = new int[logika.getKolumn()][logika.getWierszy()];
     * for (int i = 0; i < logika.getKolumn(); i++) {
     * for (int j = 0; j < logika.getWierszy(); j++) {
     * ogon[i][j] = 0;
     * }
     * }
     * }*/
    public Robak(Logika log, int numer) {
        setNumerRobaka(numer);
        int kolumna, wiersz;
        logika = log;
        ogon = new int[logika.getKolumn()][logika.getWierszy()];
        for (int i = 0; i < logika.getKolumn(); i++) {
            for (int j = 0; j < logika.getWierszy(); j++) {
                ogon[i][j] = 0;
            }
        }
        while (true) {
            kolumna = randomGenerator.nextInt(logika.getKolumn());
            wiersz = randomGenerator.nextInt(logika.getWierszy());
            if (!logika.isOgon(kolumna, wiersz) && !logika.isGłowa(kolumna, wiersz)) {
                logika.dodajGłowęNaPole(kolumna, wiersz, numer);
                głowa_kolumna = kolumna;
                głowa_wiersz = wiersz;
                break;
            }
        }
    }
    
    public Robak(Logika log, int numer, int kolumna, int wiersz) {
        setNumerRobaka(numer);
        logika = log;
        ogon = new int[logika.getKolumn()][logika.getWierszy()];
        for (int i = 0; i < logika.getKolumn(); i++) {
            for (int j = 0; j < logika.getWierszy(); j++) {
                ogon[i][j] = 0;
            }
        }
        logika.dodajGłowęNaPole(kolumna, wiersz, numer);
        głowa_kolumna = kolumna;
        głowa_wiersz = wiersz;
    }
    
    private void setKoniec(boolean kon) {
        koniec = kon;
    }
    
    private boolean getKoniec() {
        return koniec;
    }
    
    private void setNumerRobaka(int num) {
        numer = num;
    }
    
    public void ustawGłowę(int kolumna, int wiersz) {
        głowa_kolumna = kolumna;
        głowa_wiersz = wiersz;
        logika.dodajGłowęNaPole(głowa_kolumna, głowa_wiersz, numer);
    }
    
    public void dodajNowePoleNaOgon(int kolumna, int wiersz) {
        ogon[kolumna][wiersz] = 2;
        logika.dodajOgonNaPole(kolumna, wiersz, numer);
        lista.add(new Para(kolumna, wiersz));
    }
    
    public boolean isGłowa(int kolumna, int wiersz) {
        if (głowa_kolumna == kolumna && głowa_wiersz == wiersz) {
            return true;
        }
        return false;
    }
    
    public boolean isOgon(int kolumna, int wiersz) {
        if (ogon[kolumna][wiersz] == 2) {
            return true;
        }
        return false;
    }
    
    public int getGłowaKolumna() {
        return głowa_kolumna;
    }
    
    public int getGłowaWiersz() {
        return głowa_wiersz;
    }
    
    private void zmieńObecnyKierunekWLewo() {
        switch (obecny_kierunek) {
            case 1:
                obecny_kierunek = 2;
                break;
            case 2:
                obecny_kierunek = 4;
                break;
            case 3:
                obecny_kierunek = 1;
                break;
            case 4:
                obecny_kierunek = 3;
                break;
        }
    }
    
    private void zmieńObecnyKierunekWPrawo() {
        switch (obecny_kierunek) {
            case 1:
                obecny_kierunek = 3;
                break;
            case 2:
                obecny_kierunek = 1;
                break;
            case 3:
                obecny_kierunek = 4;
                break;
            case 4:
                obecny_kierunek = 2;
                break;
        }
    }
    
    private void ustalKierunekRuchu() {
        int losowanie = 0;
        losowanie = (int) (randomGenerator.nextInt(9) + 1);
        if (losowanie > 6) {
            if (losowanie == 8) {
                zmieńObecnyKierunekWLewo();
            }
            if (losowanie == 7) {
                zmieńObecnyKierunekWPrawo();
            }
        }
    }
    
    public void robakZabity() {
        for (int i = 0; i < logika.getKolumn(); i++) {
            for (int j = 0; j < logika.getWierszy(); j++) {
                if (isOgon(i, j)) {
                    logika.usuńOgonZPola(i, j);
                    ogon[i][j] = 0;
                }
            }
        }
        logika.usuńGłowęZPola(głowa_kolumna, głowa_wiersz);
        głowa_kolumna = głowa_wiersz = 0;
    }
    
    @Override
    public void run() {
        int następny_wiersz = 0;
        int następna_kolumna = 0;
        while (!koniec) {
            
            if (!logika.isGłowa(głowa_kolumna, głowa_wiersz)) {
                robakZabity();
                setKoniec(true);
                break;
            }
            
            for (int i = 0; i < lista.size(); i++) {
                System.out.println(lista.get(i).getX() + "," + lista.get(0).getY() + " ");
                if (logika.isZajęte(lista.get(i).getX(), lista.get(i).getY()) != numer) {
                    lista.remove(i);
                }
            }
            
            ustalKierunekRuchu();
            if (obecny_kierunek == 1) {
                następny_wiersz = głowa_wiersz - 1;
                if (następny_wiersz < 0) {
                    następny_wiersz = logika.getWierszy() - 1;
                }
                if (logika.isZajęte(głowa_kolumna, następny_wiersz) != 0) {
                    if (isOgon(głowa_kolumna, następny_wiersz)) {
                        ogon[głowa_kolumna][następny_wiersz] = 0;
                        logika.dodajOgonNaPole(głowa_kolumna, głowa_wiersz, numer);
                        dodajNowePoleNaOgon(głowa_kolumna, głowa_wiersz);
                        if (lista.size() > 0) {
                            logika.usuńOgonZPola(lista.get(0).getX(), lista.get(0).getY());
                            lista.remove(0);
                        }
                    } else {
                        logika.dodajOgonNaPole(głowa_kolumna, głowa_wiersz, numer);
                        dodajNowePoleNaOgon(głowa_kolumna, głowa_wiersz);
                    }
                } else {
                    logika.dodajOgonNaPole(głowa_kolumna, głowa_wiersz, numer);
                    dodajNowePoleNaOgon(głowa_kolumna, głowa_wiersz);
                    if (lista.size() > 0) {
                        logika.usuńOgonZPola(lista.get(0).getX(), lista.get(0).getY());
                        lista.remove(0);
                    }
                }
                głowa_wiersz = następny_wiersz;
                logika.dodajGłowęNaPole(głowa_kolumna, głowa_wiersz, numer);
            } else if (obecny_kierunek == 2) {
                następna_kolumna = głowa_kolumna - 1;
                if (następna_kolumna < 0) {
                    następna_kolumna = logika.getKolumn() - 1;
                }
                if (logika.isZajęte(następna_kolumna, głowa_wiersz) != 0) {
                    if (isOgon(następna_kolumna, głowa_wiersz)) {
                        ogon[następna_kolumna][głowa_wiersz] = 0;
                        logika.dodajOgonNaPole(głowa_kolumna, głowa_wiersz, numer);
                        dodajNowePoleNaOgon(głowa_kolumna, głowa_wiersz);
                        if (lista.size() > 0) {
                            logika.usuńOgonZPola(lista.get(0).getX(), lista.get(0).getY());
                            lista.remove(0);
                        }
                    } else {
                        logika.dodajOgonNaPole(głowa_kolumna, głowa_wiersz, numer);
                        dodajNowePoleNaOgon(głowa_kolumna, głowa_wiersz);
                    }
                } else {
                    logika.dodajOgonNaPole(głowa_kolumna, głowa_wiersz, numer);
                    dodajNowePoleNaOgon(głowa_kolumna, głowa_wiersz);
                    if (lista.size() > 0) {
                        logika.usuńOgonZPola(lista.get(0).getX(), lista.get(0).getY());
                        lista.remove(0);
                    }
                }
                głowa_kolumna = następna_kolumna;
                logika.dodajGłowęNaPole(głowa_kolumna, głowa_wiersz, numer);
            } else if (obecny_kierunek == 3) {
                następna_kolumna = głowa_kolumna + 1;
                if (następna_kolumna > logika.getKolumn() - 1) {
                    następna_kolumna = 0;
                }
                if (logika.isZajęte(następna_kolumna, głowa_wiersz) != 0) {
                    if (isOgon(następna_kolumna, głowa_wiersz)) {
                        ogon[następna_kolumna][głowa_wiersz] = 0;
                        logika.dodajOgonNaPole(głowa_kolumna, głowa_wiersz, numer);
                        dodajNowePoleNaOgon(głowa_kolumna, głowa_wiersz);
                        if (lista.size() > 0) {
                            logika.usuńOgonZPola(lista.get(0).getX(), lista.get(0).getY());
                            lista.remove(0);
                        }
                    } else {
                        logika.dodajOgonNaPole(głowa_kolumna, głowa_wiersz, numer);
                        dodajNowePoleNaOgon(głowa_kolumna, głowa_wiersz);
                    }
                } else {
                    logika.dodajOgonNaPole(głowa_kolumna, głowa_wiersz, numer);
                    dodajNowePoleNaOgon(głowa_kolumna, głowa_wiersz);
                    if (lista.size() > 0) {
                        logika.usuńOgonZPola(lista.get(0).getX(), lista.get(0).getY());
                        lista.remove(0);
                    }
                }
                głowa_kolumna = następna_kolumna;
                logika.dodajGłowęNaPole(głowa_kolumna, głowa_wiersz, numer);
            } else if (obecny_kierunek == 4) {
                następny_wiersz = głowa_wiersz + 1;
                if (następny_wiersz > logika.getWierszy() - 1) {
                    następny_wiersz = 0;
                }
                if (logika.isZajęte(głowa_kolumna, następny_wiersz) != 0) {
                    if (isOgon(głowa_kolumna, następny_wiersz)) {
                        ogon[głowa_kolumna][następny_wiersz] = 0;
                        logika.dodajOgonNaPole(głowa_kolumna, głowa_wiersz, numer);
                        dodajNowePoleNaOgon(głowa_kolumna, głowa_wiersz);
                        if (lista.size() > 0) {
                            logika.usuńOgonZPola(lista.get(0).getX(), lista.get(0).getY());
                            lista.remove(0);
                        }
                    } else {
                        logika.dodajOgonNaPole(głowa_kolumna, głowa_wiersz, numer);
                        dodajNowePoleNaOgon(głowa_kolumna, głowa_wiersz);
                    }
                } else {
                    logika.dodajOgonNaPole(głowa_kolumna, głowa_wiersz, numer);
                    dodajNowePoleNaOgon(głowa_kolumna, głowa_wiersz);
                    if (lista.size() > 0) {
                        logika.usuńOgonZPola(lista.get(0).getX(), lista.get(0).getY());
                        lista.remove(0);
                    }
                }
                głowa_wiersz = następny_wiersz;
                logika.dodajGłowęNaPole(głowa_kolumna, głowa_wiersz, numer);
            }
            
            
            
            
            try {
                Thread.sleep((int) (Math.random() * 1000));
            } catch (InterruptedException ex) {
                Logger.getLogger(Robak.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
