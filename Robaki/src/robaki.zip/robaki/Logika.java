/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package robaki;

/**
 * Klasa obsługująca logikę aplikacji, czyli wirtualna plansza, ruchy robaków itd.
 * @author kayne
 */
public class Logika {
    int[][] plansza;
    int[][] numery_robaków;
    int kolumn = 10;
    int wierszy = 10;
    
    public Logika() {
        plansza = new int[kolumn][wierszy];
        numery_robaków = new int[kolumn][wierszy];
        wyzerujPlanszę();
    }
    
    public Logika(int kolumny, int wiersze) {
        kolumn = kolumny;
        wierszy = wiersze;
        plansza = new int[kolumn][wierszy];
        numery_robaków = new int[kolumn][wierszy];
        wyzerujPlanszę();
    }
    
    private void wyzerujPlanszę() {
        for (int i = 0; i < kolumn; i++) {
            for (int j = 0; j < wierszy; j++) {
                plansza[i][j] = 0;
                numery_robaków[i][j] = 0;
            }
        }
    }
    
    public synchronized int getNumerRobaka(int kolumna, int wiersz) {
        return numery_robaków[kolumna][wiersz];
    }
    
    public synchronized void dodajNaPole(int kolumna, int wiersz, int numer) {
        plansza[kolumna][wiersz] = numer;
    }
    
    public synchronized int isZajęte(int kolumna, int wiersz) {
        return plansza[kolumna][wiersz];
    }
    
    public synchronized void usuńZPola(int kolumna, int wiersz) {
        plansza[kolumna][wiersz] = 0;
    }
    
    public synchronized void dodajOgonNaPole(int kolumna, int wiersz, int kolor) {
        plansza[kolumna][wiersz] = kolor;
        numery_robaków[kolumna][wiersz] = kolor;
    }
    
    public synchronized void dodajGłowęNaPole(int kolumna, int wiersz, int kolor) {
        plansza[kolumna][wiersz] = kolor;
        numery_robaków[kolumna][wiersz] = kolor;
    }
    
    public synchronized void usuńOgonZPola(int kolumna, int wiersz) {
        plansza[kolumna][wiersz] = 0;
    }
    
    public synchronized void usuńGłowęZPola(int kolumna, int wiersz) {
        plansza[kolumna][wiersz] = 0;
    }
    
    public synchronized boolean isOgon(int kolumna, int wiersz) {
        if (plansza[kolumna][wiersz] == 2) {
            return true;
        }
        return false;
    }
    
    public synchronized boolean isGłowa(int kolumna, int wiersz) {
        if (plansza[kolumna][wiersz] != 0) {
            return true;
        }
        return false;
    }
    
    public int getKolumn() {
        return kolumn;
    }
    
    public int getWierszy() {
        return wierszy;
    }
    
    public void zabijRobaka(int kolumna, int wiersz) {
        plansza[kolumna][wiersz] = 0;
    }
}
